function init() {
    var themeColor = sessionStorage.getItem('themeColor');
    applyTheme(themeColor);
}

//zastosowanie motywu do strony
function applyTheme(themeColor) {
    document.body.style.backgroundColor = themeColor;
    themeDiv.innerHTML = 'Zastosowano motyw: ' + themeColor + '.';
}

window.addEventListener("load", init, false);