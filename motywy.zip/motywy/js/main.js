var themeDiv;

function initTheme() {
    themeDiv = document.getElementById("theme");
    if (window.sessionStorage) {
        var btnResetTheme = document.getElementById("resetTheme");
        btnResetTheme.addEventListener("click", resetTheme, false);

        //procedura nasłuchu listy wyboru select
        var selThemeColor = document.getElementById("themeColor");
        selThemeColor.addEventListener("change", setTheme, false);

        if (sessionStorage.themeColor) {
            var themeColor = sessionStorage.getItem("themeColor");
            document.getElementById("themeColor").selected = true;
            applyTheme(themeColor);
        }
    } else {
        themeDiv.innerHTML = "sessionStorage nie jest obsługiwane";
    }
}

//ustawienie wybranego motywu

function setTheme() {
    var themeColor = document.getElementById("themeColor").value;
    try {
        sessionStorage.setItem('themeColor', themeColor);
        applyTheme(themeColor)
    } catch (err) {
        if (err.code == QUOTA_EXCEEDED_ERR) {
            themeDiv.innerHTML = 'Zabrakło miejsca....';
        }
    }
}

//czyszczenie koloru motywu
function resetTheme() {
    sessionStorage.removeItem('themeColor');
    document.getElementById("default").select = true;
    document.body.style.backgroundColor = '';
    themeDiv.innerHTML = 'motyw wyczyszczony!';
}

//zastosowanie motywu do strony
function applyTheme(themeColor) {
    document.body.style.backgroundColor = themeColor;
    themeDiv.innerHTML = 'Zastosowano motyw: ' + themeColor + '.';
}

window.addEventListener("load", initTheme, false);